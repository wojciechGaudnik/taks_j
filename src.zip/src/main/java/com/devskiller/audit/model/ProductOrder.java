package com.devskiller.audit.model;

import java.time.LocalDateTime;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ProductOrder {

	@Id
    private Long id;

    private String userLogin;

    private String productId;

    private LocalDateTime creationTime;

	public ProductOrder(String userLogin, String productId, LocalDateTime creationTime) {
		this.userLogin = userLogin;
		this.productId = productId;
		this.creationTime = creationTime;
	}

	protected ProductOrder() {
	}


	public Long getId() {
        return id;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public String getProductId() {
        return productId;
    }

    public LocalDateTime getCreationTime() {
        return creationTime;
    }
}
