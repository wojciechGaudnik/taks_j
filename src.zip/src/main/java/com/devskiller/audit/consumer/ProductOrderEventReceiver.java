package com.devskiller.audit.consumer;

import java.io.IOException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;

import com.devskiller.audit.service.ProductOrderEventProcessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class ProductOrderEventReceiver {

	private final ObjectMapper mapper = new ObjectMapper();

	private ProductOrderEventProcessor processor;

	public ProductOrderEventReceiver(ProductOrderEventProcessor processor) {
		mapper.registerModule(new JavaTimeModule());
		this.processor = processor;
	}

	@KafkaListener(topics = "users", groupId = "audit")
	public void receive(ConsumerRecord<?, ?> consumerRecord) throws IOException {
		ProductOrderEvent event = mapper.readValue(consumerRecord.value().toString(), ProductOrderEvent.class);
		processor.processEvent(event);
	}

}
