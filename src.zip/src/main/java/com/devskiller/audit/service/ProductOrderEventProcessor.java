package com.devskiller.audit.service;

import org.springframework.stereotype.Component;

import com.devskiller.audit.consumer.ProductOrderEvent;
import com.devskiller.audit.model.ProductOrder;
import com.devskiller.audit.repository.ProductOrderRepository;
import com.devskiller.audit.repository.UserRepository;

@Component
public class ProductOrderEventProcessor {

	private final ProductOrderRepository productOrderRepository;
	private final UserRepository userRepository;

    public ProductOrderEventProcessor(ProductOrderRepository productOrderRepository, UserRepository userRepository) {
        this.productOrderRepository = productOrderRepository;
        this.userRepository = userRepository;
    }

    public void processEvent(ProductOrderEvent event) {
		var user = userRepository.findByLogin(event.userLogin());
		if (user == null) {
			throw new RuntimeException("User not found");
		}
		ProductOrder productOrder = new ProductOrder(user.getLogin(), event.productId(), event.creationTime());
		productOrderRepository.save(productOrder);

    }

}
